//: Playground - noun: a place where people can play

import UIKit

enum Velocidades : Int {
    case Apagado = 0,
        VelocidadBaja = 20,
        VelocidadMedia = 50,
        VelocidadAlta = 120
    
    init (velocidadInicial : Velocidades){
        self = velocidadInicial
    }
}

class Auto{
    var velocidad : Velocidades
    
    init () {
        self.velocidad = Velocidades(velocidadInicial: Velocidades.Apagado)
    }
    
    func cambioDeVelocidad( ) -> ( actual : Int, velocidadEnCadena: String){
        var velocidadString : String = ""
        var velocidadInit : Int
        
        switch velocidad {
            
        case Velocidades.Apagado:
            velocidadInit = Velocidades.Apagado.rawValue
            velocidad = Velocidades.VelocidadBaja
            velocidadString = "Velocidad Apagado"
        case Velocidades.VelocidadBaja:
            velocidadInit = Velocidades.VelocidadBaja.rawValue
            velocidad = Velocidades.VelocidadMedia
            velocidadString = "Velocidad Baja"
        case Velocidades.VelocidadMedia:
            velocidadInit = Velocidades.VelocidadMedia.rawValue
            velocidad = Velocidades.VelocidadAlta
            velocidadString = "Velocidad Media"
        case Velocidades.VelocidadAlta:
            velocidadInit = Velocidades.VelocidadAlta.rawValue
            velocidad = Velocidades.VelocidadMedia
            velocidadString = "Velocidad Alta"
        default:
            velocidad = Velocidades.Apagado
            velocidadString = "Velocidad Apagado"
        }
        
        let estado = (velocidadInit,velocidadString)
        
        return estado
    }
}

var miAuto = Auto()
miAuto.velocidad

for i in 1...20 {
    var estado = miAuto.cambioDeVelocidad()
    print("\(estado.actual), \(estado.velocidadEnCadena)")
    
}


